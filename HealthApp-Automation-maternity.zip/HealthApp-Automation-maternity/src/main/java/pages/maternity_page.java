package pages;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class maternity_page extends StartupPage {

	public By getUsernameTextfieldLocator() {
		return By.id("username_id");
	}

	public By getPasswordTextboxLocator() {
		return By.xpath("//input[@id='password']");
	}

	public By getSignInButtonLocator() {
		return By.xpath("//button[@id='login']");
	}

	public By getMaternityLocator() {
		return By.xpath("//a[@href='#/Maternity']");
	}

	public By getMaternityDropdownOptionLocator(String subModuleName) {
		return By.xpath("//a/span[contains(text(),'" + subModuleName + "')]");
	}

	public By getMaternityBoxLocator() {
		return By.xpath("//ul[@id='Maternity']");
	}

	public By getAnchorTagLocatorByText(String anchorTagName) {
		return By.xpath("//a[contains(text(),'" + anchorTagName + "')]");
	}

	public By getButtonLocatorsBytext(String buttonName) {
		return By.xpath("//button[contains(text(),'" + buttonName + "')]");
	}

	public By searchBarId() {
		return By.id("quickFilterInput");
	}

	public By editInformationOfField() {
		return By.id("maternityPats");
	}

	public By getDateRangeButton() {
		return By.cssSelector("td [data-hover='dropdown']");
	}

	public By getAllMaternityPatientCheckbox() {
		return By.xpath("//label[contains(text(),'View all Maternity Patient')]/span");
	}

	public By calendarFromDropdown() {
		return By.xpath("(//input[@id='date'])[1]");
	}

	public By calendarToDropdown() {
		return By.xpath("(//input[@id='date'])[2]");
	}

	public By getStarIconLocator() {
		return By.xpath("//i[contains(@class,'icon-favourite')]/..");
	}

	public By getEditHusbandField() {
		return By.xpath("//input[@id='patHusbandName']");
	}

	public By getRowsOfResult() {
		return By.xpath("//div[not(contains(@class,'hidden'))]/div[@row-id]");
	}

	public By getHusbandNameByRowIndex(String index) {
		return By.xpath("(//div[@role='gridcell' and @col-id='HusbandName'])[" + index + "]");
	}

	public By getActualEddDates() {
		return By.xpath("//div[@role='gridcell' and @col-id='ExpectedDeliveryDate']");
	}

	public By getImageLoader() {
		return By.cssSelector("div.loading-image-holder img");
	}

	public By favouriteOrStarIconMedicalRecord() {
		return By.xpath("//i[@title='Remember this Date']");
	}

	public By getColumnDividerOnRightByColumnId(String columnId) {
		return By.xpath("//div[@col-id='" + columnId + "']/div[@ref='eResize']");
	}

	public By getColumnHeaderByColumnId(String columnId) {
		return By.xpath("//div[@col-id='" + columnId + "']");
	}

	public By getCurrentPage() {
		return By.xpath("//span[@ref='lbCurrent']");
	}

	public By getTotalRecordCount() {
		return By.xpath("//span[@ref='lbRecordCount']");
	}

	public By getMaternityAllowanceBox() {
		return By.xpath("//a[@href='#/Maternity/Reports/MaternityAllowance']");
	}

	public By getSearchFromAllPatientsCheckbox() {
		return By.xpath("//label[contains(text(),'Search From All Patients')]/span");
	}

	public By selectUserNameDropdown() {
		return By.xpath("//input[@placeholder='Select User Name']");
	}

	public By getUpdateDetailsModal() {
		return By.xpath("//span[text()='Update Details']");
	}

	public By getLocatorById(String elementId) {
		return By.id(elementId);
	}

	public By getPopUpMessageText(String msgStatus, String messageText) {
		return By.xpath("//p[contains(text(),' " + msgStatus + " ')]/../p[contains(text(),'" + messageText + "')]");
	}

	public By popupCloseButton() {
		return By.cssSelector("a.close-btn");
	}

	public By getMaternityANCModal() {
		return By.xpath("//span[text()='Maternity ANC']");
	}

	public By getMaternityRegisterModal() {
		return By.xpath("//span[text()='Maternity Register']");
	}

	public By getConcludeAlertModal() {
		return By.xpath("//span[text()='Conclude Alert !!']");
	}

	public By getRemoveAlertModal() {
		return By.xpath("//span[text()='Alert !!']");
	}

	public By getLocatorByPlaceholder(String elementPlaceholder) {
		return By.cssSelector("[placeholder='" + elementPlaceholder + "']");
	}

	public By ancVisitNumber() {
		return By.cssSelector("select[formcontrolname=\"VisitNumber\"]");
	}

	public By getGenderLocator() {
		return By.cssSelector("select[formcontrolname='Gender']");
	}

	public maternity_page(WebDriver driver) {
		super(driver);
	}

	/**
	 * @Test1.1 about this method loginTohealthAppByGivenValidCredetial()
	 * 
	 * @param : Map<String, String>
	 * @description : fill usernameTextbox & passwordTextbox and click on sign in
	 *              button
	 * @return : Boolean
	 * @author : Yaksha
	 */
	public boolean loginToHealthAppByGivenValidCredetial(Map<String, String> expectedData) throws Exception {
		Boolean textIsDisplayed = false;
		try {
			WebElement usernametextFieldWebElement = commonEvents.findElement(getUsernameTextfieldLocator());
			commonEvents.highlightElement(usernametextFieldWebElement);
			commonEvents.sendKeys(getUsernameTextfieldLocator(), expectedData.get("username"));

			WebElement passwordtextFieldWebElement = commonEvents.findElement(getPasswordTextboxLocator());
			commonEvents.highlightElement(passwordtextFieldWebElement);
			commonEvents.sendKeys(getPasswordTextboxLocator(), expectedData.get("password"));

			WebElement signinButtonWebElement = commonEvents.findElement(getPasswordTextboxLocator());
			commonEvents.highlightElement(signinButtonWebElement);
			commonEvents.click(getSignInButtonLocator());
			textIsDisplayed = true;
		} catch (Exception e) {
			throw e;
		}
		return textIsDisplayed;
	}

	/**
	 * @Test1.2 about this method scrollDownAndClickMaternityTab()
	 * 
	 * @param : null
	 * @description : verify the maternity tab, scroll to it, and click it
	 * @return : String
	 * @author : YAKSHA
	 */
	public boolean scrollDownAndClickMaternityTab() throws Exception {
		boolean scrolledTillElemet = false;
		try {
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			WebElement radiologyTab = commonEvents.findElement(getMaternityLocator());
			jsExecutor.executeScript("arguments[0].scrollIntoView(true);", radiologyTab);
			jsExecutor.executeScript("window.scrollBy(0, -50)");
			commonEvents.highlight(radiologyTab);
			commonEvents.click(radiologyTab);

			// Wait for the URL to contain "Maternity/PatientList"
			commonEvents.waitForUrlContains("Maternity/PatientList", 10);

			scrolledTillElemet = true;
		} catch (Exception e) {
			throw e;
		}
		return scrolledTillElemet;
	}

	/**
	 * @Test1.3 about this method verifyMaternityPageUrl()
	 * 
	 * @param : null
	 * @description : verify maternity page url
	 * @return : String
	 * @author : YAKSHA
	 */
	public String verifyMaternityPageUrl() throws Exception {
		try {
			String titleToVerify = commonEvents.getCurrentUrl();
			return titleToVerify;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test2 about this method clickMaternityArrowAndVerifySubModules()
	 * 
	 * @param : null
	 * @description : This method clicks on the maternity dropdown arrow and
	 *              verifies the visibility of its sub-modules such as "Maternity
	 *              List", "Payments", and "Reports".
	 * @return : boolean - Returns true if all sub-modules are visible, otherwise
	 *         false.
	 * @throws : Exception - if there is an issue interacting with the dropdown
	 *           arrow or verifying the sub-modules.
	 * @author : YAKSHA
	 */
	public boolean clickMaternityArrowAndVerifySubModules() throws Exception {
		boolean subModulesVisible = false;
		try {

			// Click the maternity dropdown arrow to expand the sub-modules
			commonEvents.click(getMaternityLocator());

			// Locate the sub-modules under the maternity section
			WebElement maternityList = commonEvents.findElement(getAnchorTagLocatorByText("Maternity List"));
			WebElement payments = commonEvents.findElement(getAnchorTagLocatorByText("Payments"));
			WebElement reports = commonEvents.findElement(getAnchorTagLocatorByText("Reports"));

			// Store the located sub-modules in a list for easy iteration
			List<WebElement> options = Arrays.asList(maternityList, payments, reports);

			// Verify that each sub-module is visible by checking its height
			for (int i = 0; i < options.size(); i++) {
				WebElement option = options.get(i);
				commonEvents.highlight(option);
				System.out.println("Is " + option.getText() + " vvisible : " + option.isDisplayed());
				if (!option.isDisplayed()) {
					subModulesVisible = false;
					throw new Exception("Sub-module visibility check failed for: " + option.getText());
				}
			}

			// Return true if all sub-modules are visible, otherwise false
			subModulesVisible = true;
		} catch (Exception e) {
			// Throw a descriptive error with additional context
			throw new Exception("Failed to verify maternity sub-modules visibility. Reason: " + e.getMessage(), e);
		}

		return subModulesVisible;
	}

	/**
	 * @Test3 about this method verifyNavigationBetweenMaternitySubModules()
	 * 
	 * @param : null
	 * @description : This method verifies if the user is able to successfully
	 *              navigate between the "Payments", "Reports", and "Maternity List"
	 *              sub-tabs within the Maternity module.
	 * @return : boolean - Returns true if navigation between all sub-tabs is
	 *         successful, otherwise false.
	 * @throws : Exception - if there is an issue clicking the sub-tab or if the
	 *           expected URL is not found.
	 * @author : YAKSHA
	 */
	public boolean verifyNavigationBetweenMaternitySubModules() throws Exception {
		try {
			// Navigate to the "Payments" sub-tab and verify the URL
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.waitForUrlContains("Maternity/Payments/PaymentPatientList", 5);

			// Navigate to the "Reports" sub-tab and verify the URL
			commonEvents.click(getAnchorTagLocatorByText("Reports"));
			commonEvents.waitForUrlContains("Maternity/Reports", 5);

			// Navigate to the "Maternity List" sub-tab and verify the URL
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));
			commonEvents.waitForUrlContains("Maternity/PatientList", 5);

			// If all navigations are successful, return true
			return true;
		} catch (Exception e) {
			// Throw a descriptive error with additional context
			throw new Exception("Navigation between maternity sub-modules failed. Reason: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test4 about this method verifyMaternityComponentsAreVisible()
	 * @param : null
	 * @description : verifies all the components of maternity list submodule
	 * @return : Boolean
	 * @author : YAKSHA
	 */
	public boolean verifyMaternityComponentsAreVisible() throws Exception {

		boolean areAllFieldsDisplayed = false;
		try {
			// Navigate to the "Maternity List" sub-tab and verify the URL

			WebElement firstButton = commonEvents.findElement(getButtonLocatorsBytext("First"));
			WebElement previousButton = commonEvents.findElement(getButtonLocatorsBytext("Previous"));
			WebElement nextButton = commonEvents.findElement(getButtonLocatorsBytext("Next"));
			WebElement lastButton = commonEvents.findElement(getButtonLocatorsBytext("Last"));
			WebElement eclipseButton = commonEvents.findElement(getButtonLocatorsBytext("..."));
			WebElement searchBarId = commonEvents.findElement(searchBarId());
			WebElement editInformationOfField = commonEvents.findElement(editInformationOfField());
			WebElement getDateRangeButton = commonEvents.findElement(getDateRangeButton());
			WebElement allMaternityPatientCheckbox = commonEvents.findElement(getAllMaternityPatientCheckbox());
			WebElement calendarFromDropdown = commonEvents.findElement(calendarFromDropdown());
			WebElement calendarToDropdown = commonEvents.findElement(calendarToDropdown());
			WebElement starIconLocator = commonEvents.findElement(getStarIconLocator());

			List<WebElement> options = Arrays.asList(firstButton, previousButton, nextButton, lastButton, eclipseButton,
					searchBarId, editInformationOfField, getDateRangeButton, allMaternityPatientCheckbox,
					calendarFromDropdown, calendarToDropdown, starIconLocator);

			for (int i = 0; i < options.size(); i++) {
				WebElement option = options.get(i);
				commonEvents.highlight(option);
				if (!option.isDisplayed()) {
					areAllFieldsDisplayed = false;
					throw new Exception("Visibility check failed for: " + option.getText());
				}
			}
			areAllFieldsDisplayed = true;
		} catch (Exception e) {
			// Throw an exception with a meaningful message if any UI component is not found
			throw new Exception("Failed to verify if all fields are displayed!", e);
		}
		// Return the result of the visibility check
		return areAllFieldsDisplayed;
	}

	/**
	 * @Test5 about this method editPatientInformationAndVerify()
	 * 
	 * @param : null
	 * @description : This method edits the patient's first name and husband's name,
	 *              and verifies that the updated husband's name is correctly
	 *              reflected in the patient details.
	 * @return : boolean - true if the patient's details are successfully updated
	 *         and verified, false otherwise.
	 * @throws : Exception - if there is an issue finding or updating the patient
	 *           details.
	 * @author : YAKSHA
	 */
	public boolean editPatientInformationAndVerify() throws Exception {
		String patientFirstName = "Edda";
		Random random = new Random();
		long randomNumber = 1000L + (long) (random.nextDouble() * 9000L);
		String updatedHusbandName = "Husband" + randomNumber;

		try {
			WebElement editInformationField = commonEvents.findElement(editInformationOfField());
			commonEvents.highlight(editInformationField).sendKeys(editInformationField, patientFirstName);
			Thread.sleep(3000);
			commonEvents.sendKeys(editInformationField, Keys.TAB);

			WebElement editHusbandNameField = commonEvents.findElement(getEditHusbandField());
			commonEvents.highlight(editHusbandNameField).sendKeys(editHusbandNameField, updatedHusbandName);

			commonEvents.click(getButtonLocatorsBytext("Register"));

			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			List<WebElement> rowsElements = commonEvents.getWebElements(getRowsOfResult());
			System.out.println("Number of elements : " + rowsElements.size());

			// Navigate to the last page if the "Last" button is enabled
			WebElement lastButton = commonEvents.findElement(getButtonLocatorsBytext("Last"));
			if (lastButton.isEnabled()) {
				commonEvents.highlight(lastButton).click(lastButton);
			}

			// Verify the updated husband's name
			String totalNumberOfVisibleRows = String.valueOf(rowsElements.size());
			WebElement actualHusbandNameElement = commonEvents
					.findElement(getHusbandNameByRowIndex(totalNumberOfVisibleRows));
			String actualHusbandName = commonEvents.getText(actualHusbandNameElement);
			System.out.println("Actual Husband Name : " + actualHusbandName);
			System.out.println("Updated Husband Name : " + actualHusbandName);

			if (actualHusbandName.trim().contains(updatedHusbandName.trim())) {
				return true;
			} else {
				throw new Exception("Verification failed: Updated husband's name does not match the expected value.");
			}
		} catch (Exception e) {
			throw new Exception("Failed to edit and verify patient information due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test6.1 about this method verifyUrlContains()
	 * 
	 * @param buttonText : String - The partial url text to verify
	 * @description : This method checks whether the current URL contains the
	 *              specified text
	 * @return : boolean
	 * @throws : Exception - if there is an issue getting the URL
	 * @author : YAKSHA
	 */
	public boolean verifyUrlContains(String urlTextToVerify) throws Exception {
		try {
			commonEvents.waitForUrlContains(urlTextToVerify, 0);
			return true;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test6.2 about this method applyDateFilter()
	 * 
	 * @param : String, String
	 * @description : Applies the date filter with date range
	 * @return : void
	 * @throws : Exception - if there is an issue finding or filling the date fields
	 * @author : YAKSHA
	 */
	public boolean applyDateFilter(String fromDate, String toDate) throws Exception {
		try {
			String fromDay, fromMonth, fromYear, toDay, toMonth, toYear;
			fromDay = fromDate.split("-")[0];
			fromMonth = fromDate.split("-")[1];
			fromYear = fromDate.split("-")[2];
			toDay = toDate.split("-")[0];
			toMonth = toDate.split("-")[1];
			toYear = toDate.split("-")[2];
			WebElement fromDateDropdown = commonEvents.findElement(calendarFromDropdown());
			WebElement toDateDropdown = commonEvents.findElement(calendarToDropdown());
			commonEvents.highlight(fromDateDropdown).sendKeys(fromDateDropdown, fromDay)
					.sendKeys(fromDateDropdown, fromMonth).sendKeys(fromDateDropdown, fromYear);
			commonEvents.highlight(toDateDropdown).sendKeys(toDateDropdown, toDay).sendKeys(toDateDropdown, toMonth)
					.sendKeys(toDateDropdown, toYear);
			commonEvents.click(getButtonLocatorsBytext("OK"));
		} catch (Exception e) {
			throw e;
		}
		return true;
	}

	/**
	 * @Test7.1 about this method clickDateRangeDropdownAndSelect()
	 * 
	 * @param valueToSelect : String - Text of the value to select from the dropdown
	 * @description : This method clicks on the date range button and selects a
	 *              value by its text.
	 * @return : boolean - true if the intended value is successfully selected,
	 *         false if not.
	 * @throws : Exception - if there is an issue finding the dropdown or its
	 *           values.
	 * @author : YAKSHA
	 */
	public boolean clickDateRangeDropdownAndSelect(String valueToSelect) throws Exception {
		try {
			// Click the date range button
			WebElement dateRangeButton = commonEvents.findElement(getDateRangeButton());
			commonEvents.highlight(dateRangeButton).click(dateRangeButton);

			// Find and select the desired value from the dropdown
			WebElement valueToSelectElement = commonEvents.findElement(getAnchorTagLocatorByText(valueToSelect));
			commonEvents.highlight(valueToSelectElement).click(valueToSelectElement);

			// Verify if the value was successfully selected
			boolean isValueSelected = commonEvents.getAttribute(valueToSelectElement, "class")
					.contains("selected-range");
			return isValueSelected;

		} catch (Exception e) {
			throw new Exception("Failed to select the value from date range dropdown due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test6.3 @Test7.2 about this method verifyResultsAppointmentDateFallsWithin()
	 * 
	 * @param fromDate : String - The start date of the range in "dd-MM-yyyy"
	 *                 format.
	 * @param toDate   : String - The end date of the range in "dd-MM-yyyy" format.
	 * @description : This method applies the specified date range and verifies that
	 *              all appointment dates in the results fall within that range.
	 * @return : boolean - true if all dates are within the specified range, false
	 *         if any date is outside the range.
	 * @throws : Exception - if there is an issue finding the date range fields or
	 *           parsing the dates.
	 * @author : YAKSHA
	 */
	public boolean verifyResultsAppointmentDateFallsWithin(String fromDate, String toDate) throws Exception {
		try {
			// Formatters for date conversion
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			Thread.sleep(3000); // To let the results gets refreshed

			// Parse the from and to dates
			LocalDate from = LocalDate.parse(fromDate, formatter);
			LocalDate to = LocalDate.parse(toDate, formatter);

			// Retrieve the list of dates from the results
			List<WebElement> actualDatesAfterFilterApplied = commonEvents.getWebElements(getActualEddDates());

			for (WebElement dateElement : actualDatesAfterFilterApplied) {
				commonEvents.highlight(dateElement);
				String dateText = dateElement.getText();

				try {
					// Convert the date string to LocalDate
					LocalDate date = LocalDate.parse(dateText, inputFormatter);

					// Check if the date is within the specified range
					if (date.isBefore(from) || date.isAfter(to)) {
						System.out.println("Date " + dateText + " is outside the range " + fromDate + " to " + toDate);
						return false;
					}
				} catch (Exception e) {
					System.out.println("Date parsing failed for: " + dateText);
					return false;
				}
			}
			return true;

		} catch (Exception e) {
			throw new Exception("Failed to verify dates within the specified range due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test8 about this method verifyViewAllMaternityPatientCheckBoxFunctionality()
	 * 
	 * @param : null
	 * @description : Verifies the records count increases after clicking "View all
	 *              maternity patient" checkbox
	 * @return : boolean - true if the count increased and false if it didn't
	 *         increase
	 * @throws : Exception - if there is an issue finding or clicking the checkbox
	 * @author : YAKSHA
	 */
	public boolean verifyViewAllMaternityPatientCheckBoxFunctionality() throws Exception {
		try {
			WebElement viewAllMaternityPatientCheckbox = commonEvents.findElement(getAllMaternityPatientCheckbox());
			WebElement totalRecordCountElement = commonEvents.findElement(getTotalRecordCount());
			int initialCount = Integer.parseInt(totalRecordCountElement.getText());
			commonEvents.highlight(viewAllMaternityPatientCheckbox).click(viewAllMaternityPatientCheckbox);
			Thread.sleep(3000);
			int updatedCount = Integer.parseInt(totalRecordCountElement.getText());
			if (updatedCount > initialCount) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test9 about this method searchAndVerifyKeywordInEveryResult()
	 * 
	 * @param keywordToVerify : String - The keyword to search for
	 * @description : This method searches with the provided keyword and verifies if
	 *              every row in the result contains at least one cell that includes
	 *              the keyword.
	 * @return : boolean - True if the keyword is found in every row, false
	 *         otherwise.
	 * @throws : Exception - if there is an issue filling the search bar or
	 *           verifying the rows.
	 * @author : YAKSHA
	 */
	public boolean searchAndVerifyKeywordInEveryResult(String keywordToVerify) throws Exception {
		try {
			boolean keywordFoundInAllRows = true;

			// Find and highlight the search bar, then enter the keyword
			WebElement searchBar = commonEvents.findElement(searchBarId());
			commonEvents.highlightElement(searchBar);
			commonEvents.sendKeys(searchBar, keywordToVerify);

			// Wait for the results to load, if necessary
			Thread.sleep(2000);

			// Get all rows of the search result
			List<WebElement> rows = commonEvents.getWebElements(getRowsOfResult());

			// Verify the keyword is present in each row
			for (WebElement row : rows) {
				commonEvents.highlight(row);
				String rowText = row.getText();

				if (!rowText.contains(keywordToVerify)) {
					keywordFoundInAllRows = false;
					break; // Exit the loop early if the keyword is not found in any row
				}
			}

			return keywordFoundInAllRows;
		} catch (Exception e) {
			throw new Exception("Failed to verify keyword in all rows due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test10 about this method verifyTooltipAndtext()
	 * 
	 * @param : null
	 * @description : This method verifies tooltip and the text after hovers
	 * @return : boolean - true if successfully hover and verify the text present
	 * @throws : Exception - if there is an issue while finding star tooltip
	 * @author : YAKSHA
	 * @return
	 */

	public String verifyToolTipText() throws Exception {

		String toolTipValue = "";
		try {
			// Navigate to MR Inpatient List and MR Outpatient List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			WebElement toolTip = commonEvents.findElement(favouriteOrStarIconMedicalRecord());
			toolTipValue = commonEvents.highlight(toolTip).getAttribute(toolTip, "title");
			System.out.println("Tool tip title : " + toolTipValue);
		} catch (Exception e) {
			throw e;
		}
		return toolTipValue;
	}

	/**
	 * @Test11 about this method verifyViewbuttonFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies the functionality of the "View" button by
	 *              navigating to the Maternity List, selecting the last "View"
	 *              button, and updating the patient's husband name. It then checks
	 *              if the success message is displayed.
	 * @return : String - The success message if the update is successful.
	 * @throws : Exception - if there is an issue with viewing or updating the
	 *           patient details.
	 * @author : YAKSHA
	 */
	public String verifyViewbuttonFunctionality() throws Exception {
		String updateMessage = "";
		try {
			// Navigate to the Payments page, then to the Maternity List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			Thread.sleep(2000); // to avoid stale element exception

			// Get the list of "View" buttons and click the last one
			List<WebElement> viewButtons = commonEvents.getWebElements(getAnchorTagLocatorByText("View"));
			WebElement lastViewButton = viewButtons.get(viewButtons.size() - 1);
			commonEvents.waitTillElementVisible(lastViewButton, 30000);
			commonEvents.highlight(lastViewButton).click(lastViewButton);

			// Assert that the Update Details modal is displayed
			Assert.assertTrue(commonEvents.isDisplayed(getUpdateDetailsModal()));

			// Clear and update the husband's name with a random name
			WebElement husbandName = commonEvents.findElement(getLocatorById("patHusbandName"));
			commonEvents.highlight(husbandName).clear(husbandName);

			String randomLastName = commonEvents.randomString(4);
			System.out.println("Random Name: " + "Husband" + randomLastName);
			commonEvents.sendKeys(husbandName, "Husband" + randomLastName);

			// Click the "Update Details" button
			commonEvents.click(getButtonLocatorsBytext("Update Details"));

			// Verify the success message
			WebElement element = commonEvents
					.findElement(getPopUpMessageText("success", "Patient details updated successfully."));
			updateMessage = element.getText();
			System.out.println("Actual Success Message: " + updateMessage);

			// Close the popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw new Exception("Failed to verify 'View' button functionality due to: " + e.getMessage(), e);
		}

		return updateMessage;
	}

	/**
	 * @Test12 about this method verifyANCbuttonFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies the functionality of the "ANC" button by
	 *              navigating to the Maternity List, selecting the last "ANC"
	 *              button, and updating the ANC details. It then checks if the
	 *              success message is displayed.
	 * @return : String - The success message if the update is successful.
	 * @throws : Exception - if there is an issue with viewing or updating the ANC
	 *           details.
	 * @author : YAKSHA
	 */
	public String verifyANCbuttonFunctionality() throws Exception {
		String ancUpdateMessage = "";
		try {
			// Navigate to the Payments page, then to the Maternity List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			Thread.sleep(2000); // Wait to avoid stale element exception

			// Get the list of "ANC" buttons and click the last one
			List<WebElement> ancButtons = commonEvents.getWebElements(getAnchorTagLocatorByText("ANC"));
			WebElement lastANCButton = ancButtons.get(ancButtons.size() - 1);
			commonEvents.waitTillElementVisible(lastANCButton, 30000);
			commonEvents.highlight(lastANCButton).click(lastANCButton);

			// Assert that the ANC modal is displayed
			Assert.assertTrue(commonEvents.isDisplayed(getMaternityANCModal()));

			// Clear and update the ANC fields with sample data
			WebElement ancCondition = commonEvents.findElement(getLocatorByPlaceholder("Condition of ANC"));
			WebElement ancPlace = commonEvents.findElement(getLocatorByPlaceholder("Place Of ANC"));
			WebElement pregnancyPeriod = commonEvents.findElement(getLocatorByPlaceholder("Pregnancy Period"));
			WebElement weightInkgs = commonEvents.findElement(getLocatorByPlaceholder("Weight in Kgs"));

			commonEvents.highlight(ancCondition).sendKeys(ancCondition, "Good");
			commonEvents.highlight(ancPlace).sendKeys(ancPlace, "Home");
			commonEvents.highlight(pregnancyPeriod).sendKeys(pregnancyPeriod, "6");
			commonEvents.highlight(weightInkgs).sendKeys(weightInkgs, "70");

			WebElement dropdownElement = commonEvents.findElement(ancVisitNumber());
			Select dropdown = new Select(dropdownElement);

			// Select the option by value
			dropdown.selectByValue("1: 1");

			// Click the "Add" button
			commonEvents.click(getButtonLocatorsBytext("Add"));

			// Verify the success message
			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("success", "ANC successfully Updated"));
			ancUpdateMessage = successMessageElement.getText();
			System.out.println("Actual Success Message: " + ancUpdateMessage);

			// Close the popup and the ANC details form
			commonEvents.click(popupCloseButton());
			commonEvents.click(getButtonLocatorsBytext("Close"));

		} catch (Exception e) {
			commonEvents.click(getButtonLocatorsBytext("Close"));
			throw new Exception("Failed to verify 'ANC' button functionality due to: " + e.getMessage(), e);
		}

		return ancUpdateMessage;
	}

	/**
	 * @Test13 about this method verifyMatRegisterbuttonFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies the functionality of the "Mat-Register"
	 *              button by navigating to the Maternity List, selecting the first
	 *              "..." button, and updating the maternity register details. It
	 *              then checks if the success message is displayed.
	 * @return : String - The success message if the update is successful.
	 * @throws : Exception - if there is an issue with viewing or updating the
	 *           maternity register details.
	 * @author : YAKSHA
	 */
	public String verifyMatRegisterbuttonFunctionality() throws Exception {
		String matRegisterMessage = "";
		try {
			// Navigate to the Payments page, then to the Maternity List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			Thread.sleep(1000); // Wait to avoid stale element exception

			// Get the list of "..." buttons and click the first one
			List<WebElement> ellipsisButtons = commonEvents.getWebElements(getButtonLocatorsBytext("..."));
			WebElement firstEllipsisButton = ellipsisButtons.get(0);
			commonEvents.waitTillElementVisible(firstEllipsisButton, 30000);
			commonEvents.highlight(firstEllipsisButton).click(firstEllipsisButton);

			// Get the list of "Mat-Register" buttons and click the first one
			List<WebElement> matRegisterButtons = commonEvents
					.getWebElements(getAnchorTagLocatorByText("Mat-Register"));
			WebElement firstMatRegisterButton = matRegisterButtons.get(0);
			commonEvents.waitTillElementVisible(firstMatRegisterButton, 30000);
			commonEvents.highlight(firstMatRegisterButton).click(firstMatRegisterButton);

			// Assert that the Maternity Register modal is displayed
			Assert.assertTrue(commonEvents.isDisplayed(getMaternityRegisterModal()));

			// Clear and update the Maternity Register fields with sample data
			WebElement placeOfDelivery = commonEvents.findElement(getLocatorById("placeOfDelivery"));
			WebElement enterTypeOfDelivery = commonEvents
					.findElement(getLocatorByPlaceholder("Enter type of Delivery"));
			WebElement enterPresentation = commonEvents.findElement(getLocatorByPlaceholder("Enter Presentation"));
			WebElement enterComplication = commonEvents.findElement(getLocatorByPlaceholder("Enter Complication"));
			WebElement gender = commonEvents.findElement(getGenderLocator());

			commonEvents.highlight(placeOfDelivery).sendKeys(placeOfDelivery, "Hospital");

			Select typeOfDeliveryDropdown = new Select(enterTypeOfDelivery);
			Select presentationDropdown = new Select(enterPresentation);
			Select complicationDropdown = new Select(enterComplication);
			Select genderDropdown = new Select(gender);

			// Select the options by value
			typeOfDeliveryDropdown.selectByValue("1");
			presentationDropdown.selectByValue("shoulder");
			complicationDropdown.selectByValue("Ectopic Pregnancy");
			genderDropdown.selectByValue("Male");

			// Update additional fields
			commonEvents.click(getLocatorById("babyWeight")).sendKeys(getLocatorById("babyWeight"), "1000");
			commonEvents.click(getLocatorByPlaceholder("Outcome of the baby"))
					.sendKeys(getLocatorByPlaceholder("Outcome of the baby"), "Alive");
			commonEvents.click(getLocatorByPlaceholder("Outcome of the Mother"))
					.sendKeys(getLocatorByPlaceholder("Outcome of the Mother"), "Alive");

			// Click the "Save" button
			commonEvents.click(getButtonLocatorsBytext("Save"));

			// Verify the success message
			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("success", "Registered successfully."));
			matRegisterMessage = successMessageElement.getText();
			System.out.println("Actual Success Message: " + matRegisterMessage);

			// Close the popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw new Exception("Failed to verify 'Mat-Register' button functionality due to: " + e.getMessage(), e);
		}

		return matRegisterMessage;
	}

	/**
	 * @Test14 about this method verifyConcludeButtonFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies the functionality of the "Conclude"
	 *              button by navigating to the Maternity List, selecting the first
	 *              "..." button, and concluding the maternity record. It then
	 *              checks if the success message is displayed.
	 * @return : String - The success message if the conclusion is successful.
	 * @throws : Exception - if there is an issue with concluding the maternity
	 *           record.
	 * @author : YAKSHA
	 */
	public String verifyConcludeButtonFunctionality() throws Exception {
		String matRegisterMessage = "";
		try {
			// Navigate to the Payments page, then to the Maternity List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			Thread.sleep(1000); // Wait to avoid stale element exception

			// Get the list of "..." buttons and click the first one
			List<WebElement> ellipsisButtons = commonEvents.getWebElements(getButtonLocatorsBytext("..."));
			WebElement firstEllipsisButton = ellipsisButtons.get(0);
			commonEvents.waitTillElementVisible(firstEllipsisButton, 30000);
			commonEvents.highlight(firstEllipsisButton).click(firstEllipsisButton);

			// Get the list of "Conclude" buttons and click the first one
			List<WebElement> concludeButtons = commonEvents.getWebElements(getAnchorTagLocatorByText("Conclude"));
			WebElement firstConcludeButton = concludeButtons.get(0);
			commonEvents.waitTillElementVisible(firstConcludeButton, 30000);
			commonEvents.highlight(firstConcludeButton).click(firstConcludeButton);

			// Assert that the Conclude alert modal is displayed
			Assert.assertTrue(commonEvents.isDisplayed(getConcludeAlertModal()));

			// Click the "Conclude" button within the modal
			commonEvents.click(getButtonLocatorsBytext("Conclude"));

			// Verify the success message
			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("success", "Successfully Concluded."));
			matRegisterMessage = successMessageElement.getText();
			System.out.println("Actual Success Message: " + matRegisterMessage);

			// Close the popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw new Exception("Failed to verify 'Conclude' button functionality due to: " + e.getMessage(), e);
		}

		return matRegisterMessage;
	}

	/**
	 * @Test15 about this method verifyMatRegisterbuttonFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies the functionality of the "Mat-Register"
	 *              button by navigating to the Maternity List, selecting the first
	 *              "..." button, and updating the maternity register details. It
	 *              then checks if the success message is displayed.
	 * @return : String - The success message if the update is successful.
	 * @throws : Exception - if there is an issue with viewing or updating the
	 *           maternity register details.
	 * @author : YAKSHA
	 */
	public String verifyRemoveButtonFunctionality() throws Exception {
		String matRegisterMessage = "";
		try {
			// Navigate to the Payments page, then to the Maternity List
			commonEvents.click(getAnchorTagLocatorByText("Payments"));
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			Thread.sleep(1000); // Wait to avoid stale element exception

			// Get the list of "..." buttons and click the first one
			List<WebElement> ellipsisButtons = commonEvents.getWebElements(getButtonLocatorsBytext("..."));
			WebElement firstEllipsisButton = ellipsisButtons.get(0);
			commonEvents.waitTillElementVisible(firstEllipsisButton, 30000);
			commonEvents.highlight(firstEllipsisButton).click(firstEllipsisButton);

			// Get the list of "Mat-Register" buttons and click the first one
			List<WebElement> removeButtons = commonEvents.getWebElements(getAnchorTagLocatorByText("Remove"));
			WebElement firstRemoveButton = removeButtons.get(0);
			commonEvents.waitTillElementVisible(firstRemoveButton, 30000);
			commonEvents.highlight(firstRemoveButton).click(firstRemoveButton);

			// Assert that the Maternity Register modal is displayed
			Assert.assertTrue(commonEvents.isDisplayed(getRemoveAlertModal()));

			// Click the "Save" button
			commonEvents.click(getButtonLocatorsBytext("Remove"));

			// Verify the success message
			WebElement successMessageElement = commonEvents
					.findElement(getPopUpMessageText("success", "Successfully Removed."));
			matRegisterMessage = successMessageElement.getText();
			System.out.println("Actual Success Message: " + matRegisterMessage);

			// Close the popup
			commonEvents.click(popupCloseButton());

		} catch (Exception e) {
			throw new Exception("Failed to verify 'Mat-Register' button functionality due to: " + e.getMessage(), e);
		}

		return matRegisterMessage;
	}

	/**
	 * @Test16 about this method verifyColumnsAreStretchableFromRight()
	 * 
	 * @param columnId : String - The ID of the column to verify.
	 * @description : This method verifies if the specified column is stretchable by
	 *              dragging the right divider and checking if the column width
	 *              increases.
	 * @return : boolean - true if the column width increases (indicating it is
	 *         stretchable), false if the width does not change.
	 * @throws : Exception - if there is an issue finding the column or performing
	 *           the stretch action.
	 * @author : YAKSHA
	 */
	public boolean verifyColumnsAreStretchableFromRight(String columnId) throws Exception {
		try {
			// Locate the column by its ID and get its initial width
			WebElement columnElement = driver.findElement(getColumnHeaderByColumnId(columnId));
			int initialWidth = columnElement.getRect().getWidth();

			// Locate the column divider and perform the stretch action
			WebElement columnDivider = commonEvents.findElement(getColumnDividerOnRightByColumnId(columnId));
			Actions actions = new Actions(driver);
			actions.dragAndDropBy(columnDivider, 10, 0).perform();

			// Get the updated width of the column after stretching
			int updatedWidth = columnElement.getRect().getWidth();

			// Check if the column width has increased
			boolean isColumnStretchable = updatedWidth > initialWidth;

			// Reset the column width back to its original state
			actions.dragAndDropBy(columnDivider, -10, 0).perform();

			return isColumnStretchable;
		} catch (Exception e) {
			throw new Exception(
					"Failed to verify if the column '" + columnId + "' is stretchable due to: " + e.getMessage(), e);
		}
	}

	/**
	 * about this method verifyCurrentPageIs()
	 * 
	 * @param : String - expected current page
	 * @description : This method verifies whether the current page matches with the
	 *              expected current page
	 * @return : boolean - true if the current page matches with the expected
	 *         current page and false they don't match
	 * @throws : Exception - if there is an issue finding the element button
	 * @author : YAKSHA
	 */
	public boolean verifyCurrentPageIs(String expectedCurrentPage) throws Exception {
		try {
			WebElement currentpageElement = commonEvents.findElement(getCurrentPage());
			String elementText = commonEvents.getText(currentpageElement);
			return elementText.contains(expectedCurrentPage);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Test17 about this method verifyPaginationFunctionality()
	 * 
	 * @param null
	 * @description : This method verifies that the pagination functionality is
	 *              working correctly by navigating between pages and checking if
	 *              the page numbers update as expected.
	 * @return : boolean - true if the pagination is working correctly (i.e., page
	 *         numbers change when navigating), false if it does not work as
	 *         expected.
	 * @throws : Exception - if there is an issue finding or interacting with
	 *           pagination elements.
	 * @author : YAKSHA
	 */
	public boolean verifyPaginationFunctionality() throws Exception {
		try {
			// Select "All Maternity Patients" checkbox
			WebElement allMaternityPatientCheckbox = commonEvents.findElement(getAllMaternityPatientCheckbox());
			commonEvents.highlight(allMaternityPatientCheckbox).click(allMaternityPatientCheckbox);

			// Apply date filter from 01-01-2023 to the current date
			LocalDate currentDate = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String toDate = currentDate.format(formatter);
			Thread.sleep(3000);
			applyDateFilter("01-01-2023", toDate);

			// Scroll to the bottom of the page
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
			Thread.sleep(5000);

			// Verify that the current page is "1"
			boolean isCurrentPage1 = verifyCurrentPageIs("1");

			// Click the "Next" button and verify that the current page is "2"
			commonEvents.click(getButtonLocatorsBytext("Next"));
			boolean isCurrentPage2 = verifyCurrentPageIs("2");

			// Click the "Previous" button and verify that the current page is "1" again
			commonEvents.click(getButtonLocatorsBytext("Previous"));

			// Return true if both page transitions were successful, otherwise false
			if (isCurrentPage1 && isCurrentPage2) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			throw new Exception("Failed to verify pagination functionality due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test18 about this method verifyPaymentsComponentsAreVisible()
	 * 
	 * @param : null
	 * @description : This method verifies that all components of the Payments
	 *              submodule (including buttons, search bar, and checkboxes) are
	 *              visible and highlighted.
	 * @return : boolean - true if all components are displayed, false if any
	 *         component is not displayed.
	 * @throws : Exception - if any component is not visible or if an error occurs
	 *           during the process.
	 * @author : YAKSHA
	 */
	public boolean verifyPaymentsComponentsAreVisible() throws Exception {
		boolean areAllFieldsDisplayed = false;
		try {
			// Navigate to Payments submodule
			commonEvents.click(getAnchorTagLocatorByText("Payments"));

			// Identify the necessary components
			WebElement printButton = commonEvents.findElement(getButtonLocatorsBytext("Print"));
			WebElement firstButton = commonEvents.findElement(getButtonLocatorsBytext("First"));
			WebElement previousButton = commonEvents.findElement(getButtonLocatorsBytext("Previous"));
			WebElement nextButton = commonEvents.findElement(getButtonLocatorsBytext("Next"));
			WebElement lastButton = commonEvents.findElement(getButtonLocatorsBytext("Last"));
			WebElement paymentButton = commonEvents.findElement(getAnchorTagLocatorByText("Payment"));
			WebElement searchBarId = commonEvents.findElement(searchBarId());
			WebElement searchFromAllPatientsCheckbox = commonEvents.findElement(getSearchFromAllPatientsCheckbox());

			// Store components in a list for iteration
			List<WebElement> options = Arrays.asList(printButton, firstButton, previousButton, nextButton, lastButton,
					paymentButton, searchBarId, searchFromAllPatientsCheckbox);

			// Iterate over each component to verify visibility
			for (WebElement option : options) {
				commonEvents.highlight(option);
				if (!option.isDisplayed()) {
					throw new Exception("Visibility check failed for component: " + option.getText());
				}
			}

			// All components are displayed
			areAllFieldsDisplayed = true;
			return areAllFieldsDisplayed;

		} catch (Exception e) {
			throw new Exception("Failed to verify the visibility of Payments components due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test19 about this method verifySearchFromAllPatientCheckboxFunctionality()
	 * 
	 * @param : null
	 * @description : This method verifies if the "Search From All Patients"
	 *              checkbox is functioning correctly by comparing the record count
	 *              before and after the checkbox is selected.
	 * @return : boolean - true if the record count increases after selecting the
	 *         checkbox, false if the record count does not change.
	 * @throws : Exception - if there is an issue finding or interacting with the
	 *           checkbox or record count element.
	 * @author : YAKSHA
	 */
	public boolean verifySearchFromAllPatientCheckboxFunctionality() throws Exception {
		try {
			commonEvents.click(getAnchorTagLocatorByText("Maternity List"));

			// Find and store the total record count before clicking the checkbox
			WebElement totalRecordElement = commonEvents.findElement(getTotalRecordCount());
			int previousRecordCount = Integer.parseInt(commonEvents.getText(totalRecordElement));

			// Highlight and click the "Search From All Patients" checkbox
			WebElement viewAllMaternityPatientsCheckbox = commonEvents.findElement(getAllMaternityPatientCheckbox());
			commonEvents.highlight(viewAllMaternityPatientsCheckbox).click(viewAllMaternityPatientsCheckbox);

			// Get the updated record count after clicking the checkbox
			int updatedRecordCount = Integer.parseInt(commonEvents.getText(totalRecordElement));

			// Verify if the record count increased
			if (updatedRecordCount > previousRecordCount) {
				return true;
			} else {
				throw new Exception(
						"Search From All Patients checkbox functionality failed: Record count did not increase.");
			}
		} catch (Exception e) {
			throw new Exception(
					"Failed to verify Search From All Patients checkbox functionality due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test20 about this method verifyReportsComponentsAreVisible()
	 * 
	 * @param : null
	 * @description : This method verifies that all components of the Reports
	 *              submodule (including buttons, dropdowns, and icons) are visible
	 *              and highlighted.
	 * @return : boolean - true if all components are displayed, false if any
	 *         component is not displayed.
	 * @throws : Exception - if any component is not visible or if an error occurs
	 *           during the process.
	 * @author : YAKSHA
	 */
	public boolean verifyReportsComponentsAreVisible() throws Exception {
		boolean areAllFieldsDisplayed = false;
		try {
			// Navigate to Reports submodule
			commonEvents.click(getAnchorTagLocatorByText("Reports"));

			// Interact with the Maternity Allowance box
			WebElement maternityAllowanceBox = commonEvents.findElement(getMaternityAllowanceBox());
			commonEvents.highlight(maternityAllowanceBox).click(maternityAllowanceBox);
			commonEvents.click(getButtonLocatorsBytext("Show Report"));

			// Identify the necessary components
			WebElement printButton = commonEvents.findElement(getButtonLocatorsBytext("Print"));
			WebElement firstButton = commonEvents.findElement(getButtonLocatorsBytext("First"));
			WebElement previousButton = commonEvents.findElement(getButtonLocatorsBytext("Previous"));
			WebElement nextButton = commonEvents.findElement(getButtonLocatorsBytext("Next"));
			WebElement lastButton = commonEvents.findElement(getButtonLocatorsBytext("Last"));
			WebElement exportButton = commonEvents.findElement(getButtonLocatorsBytext("Export"));
			WebElement searchBarId = commonEvents.findElement(searchBarId());
			WebElement calendarFromDropdown = commonEvents.findElement(calendarFromDropdown());
			WebElement calendarToDropdown = commonEvents.findElement(calendarToDropdown());
			WebElement starIconLocator = commonEvents.findElement(getStarIconLocator());
			WebElement selectUserNameDropdown = commonEvents.findElement(selectUserNameDropdown());

			// Store components in a list for iteration
			List<WebElement> options = Arrays.asList(printButton, firstButton, previousButton, nextButton, lastButton,
					exportButton, searchBarId, calendarFromDropdown, calendarToDropdown, starIconLocator,
					selectUserNameDropdown);

			// Iterate over each component to verify visibility
			for (WebElement option : options) {
				commonEvents.highlight(option);
				if (!option.isDisplayed()) {
					throw new Exception("Visibility check failed for component: " + option.getText());
				}
			}

			// All components are displayed
			areAllFieldsDisplayed = true;
			return areAllFieldsDisplayed;

		} catch (Exception e) {
			throw new Exception("Failed to verify the visibility of Reports components due to: " + e.getMessage(), e);
		}
	}

	/**
	 * @Test21 about this method verifyFileDownloaded()
	 * 
	 * @param partialFileName - The partial name of the file to check for download.
	 * @description : This method verifies if a file with the specified partial name
	 *              has been downloaded.
	 * @return boolean - true if the file is found, otherwise false.
	 * @throws InterruptedException - if the thread is interrupted while waiting for
	 *                              the file to download.
	 * @author : YAKSHA
	 */
	public boolean verifyFileDownloaded(String partialFileName) throws InterruptedException {
		try {

			// Click the "Export" button under "Reports" module
			WebElement exportButton = commonEvents.findElement(getButtonLocatorsBytext("Export"));
			commonEvents.highlight(exportButton).click(exportButton);

			// Define the download path
			String downloadPath = System.getProperty("user.dir") + "\\downloads";
			File dir = new File(downloadPath);
			boolean found = false;

			// Print debug information
			System.out.println("Checking download directory: " + downloadPath);

			// Check the download directory for the file for up to 30 seconds
			for (int i = 0; i < 30; i++) {
				File[] files = dir.listFiles();
				if (files != null) {
					System.out.println("Files in download directory:");
					for (File file : files) {
						System.out.println(" - " + file.getName());
						if (file.getName().contains(partialFileName) && !file.getName().endsWith(".tmp")) {
							found = true;
							break;
						}
					}
				}
				if (found) {
					break;
				}
				Thread.sleep(1000);
			}

			return found;
		} catch (InterruptedException e) {
			throw e;
		}
	}

}
